<?php

namespace Tests\Unit\App\Http\Controllers\Api;

use App\Database\Models\User;
use Tests\Unit\App\Http\Controllers\Api\_TestCase;

class AuthSignOutControllerTest extends _TestCase {

    public function testStore()
    {
        $user = $this->factory(User::class)->create([
            'id' => 1,
            'email' => 'abc123@example.com',
            'password' => bcrypt('abcdef')
        ]);

        auth()->setUser($user);

        $this->when(function () {

            $this->assertResult(null);
            $this->assertEquals(auth()->user(), null);
        });
    }

}
