<?php

namespace Tests\Unit\App\Http\Controllers\Api;

use App\Database\Models\Activity;
use App\Database\Models\Card;
use App\Database\Models\Match;
use App\Database\Models\User;
use App\Services\Card\CardPagingService;
use Tests\Unit\App\Http\Controllers\Api\_TestCase;

class CardControllerTest extends _TestCase {

    public function defaultForIndex()
    {
        return [];
    }

    public function testIndex()
    {
        $namedIds = [];
        $rand = rand(0, 1);
        $user1 = $this->factory(User::class)->create([
            User::ID => 1,
            User::GENDER => $rand ? User::GENDER_MAN : User::GENDER_WOMAN
        ]);
        $user2 = $this->factory(User::class)->create([
            User::ID => 2,
            User::GENDER => $rand ? User::GENDER_WOMAN : User::GENDER_MAN
        ]);
        $user3 = $this->factory(User::class)->create([
            User::ID => 3,
            User::GENDER => $rand ? User::GENDER_MAN : User::GENDER_WOMAN
        ]);

        $this->factory(Match::class)->create([
            Match::MAN_ID => $rand ? 1 : 2,
            Match::WOMAN_ID => $rand ? 2 : 1,
            Match::CARDS => [[
                Card::ID => $namedIds['1_ch_none_2_sh_none'] = 201,
                Card::CHOOSER_ID => 1,
                Card::SHOWNER_ID => 2,
                Card::ACTIVITIES => []
            ], [
                Card::ID => $namedIds['1_ch_flip_2_sh_none'] = 202,
                Card::CHOOSER_ID => 1,
                Card::SHOWNER_ID => 2,
                Card::ACTIVITIES => [[
                    Activity::TYPE => Activity::TYPE_CARD_FLIP,
                    Activity::USER_ID => 1
                ]]
            ], [
                Card::ID => $namedIds['1_ch_open_2_sh_none'] = 203,
                Card::CHOOSER_ID => 1,
                Card::SHOWNER_ID => 2,
                Card::ACTIVITIES => [[
                    Activity::TYPE => Activity::TYPE_CARD_OPEN,
                    Activity::USER_ID => 1
                ]]
            ], [
                Card::ID => $namedIds['1_ch_prop_2_sh_none'] = 204,
                Card::CHOOSER_ID => 1,
                Card::SHOWNER_ID => 2,
                Card::ACTIVITIES => [[
                    Activity::TYPE => Activity::TYPE_CARD_PROPOSE,
                    Activity::USER_ID => 1
                ]]
            ], [
                Card::ID => $namedIds['1_ch_none_2_sh_flip'] = 205,
                Card::CHOOSER_ID => 1,
                Card::SHOWNER_ID => 2,
                Card::ACTIVITIES => [[
                    Activity::TYPE => Activity::TYPE_CARD_FLIP,
                    Activity::USER_ID => 2
                ]]
            ], [
                Card::ID => $namedIds['1_ch_flip_2_sh_flip'] = 206,
                Card::CHOOSER_ID => 1,
                Card::SHOWNER_ID => 2,
                Card::ACTIVITIES => [[
                    Activity::TYPE => Activity::TYPE_CARD_FLIP,
                    Activity::USER_ID => 1
                ], [
                    Activity::TYPE => Activity::TYPE_CARD_FLIP,
                    Activity::USER_ID => 2
                ]]
            ], [
                Card::ID => $namedIds['1_ch_open_2_sh_flip'] = 207,
                Card::CHOOSER_ID => 1,
                Card::SHOWNER_ID => 2,
                Card::ACTIVITIES => [[
                    Activity::TYPE => Activity::TYPE_CARD_OPEN,
                    Activity::USER_ID => 1,
                ], [
                    Activity::TYPE => Activity::TYPE_CARD_FLIP,
                    Activity::USER_ID => 2
                ]]
            ], [
                Card::ID => $namedIds['1_ch_prop_2_sh_flip'] = 208,
                Card::CHOOSER_ID => 1,
                Card::SHOWNER_ID => 2,
                Card::ACTIVITIES => [[
                    Activity::TYPE => Activity::TYPE_CARD_PROPOSE,
                    Activity::USER_ID => 1
                ], [
                    Activity::TYPE => Activity::TYPE_CARD_FLIP,
                    Activity::USER_ID => 2
                ]]
            ], [
                Card::ID => $namedIds['1_ch_none_2_sh_open'] = 209,
                Card::CHOOSER_ID => 1,
                Card::SHOWNER_ID => 2,
                Card::ACTIVITIES => [[
                    Activity::TYPE => Activity::TYPE_CARD_FLIP,
                    Activity::USER_ID => 2
                ], [
                    Activity::TYPE => Activity::TYPE_CARD_OPEN,
                    Activity::USER_ID => 2
                ]]
            ], [
                Card::ID => $namedIds['1_ch_flip_2_sh_open'] = 210,
                Card::CHOOSER_ID => 1,
                Card::SHOWNER_ID => 2,
                Card::ACTIVITIES => [[
                    Activity::TYPE => Activity::TYPE_CARD_FLIP,
                    Activity::USER_ID => 1
                ], [
                    Activity::TYPE => Activity::TYPE_CARD_FLIP,
                    Activity::USER_ID => 2
                ], [
                    Activity::TYPE => Activity::TYPE_CARD_OPEN,
                    Activity::USER_ID => 2
                ]]
            ], [
                Card::ID => $namedIds['1_ch_open_2_sh_open'] = 211,
                Card::CHOOSER_ID => 1,
                Card::SHOWNER_ID => 2,
                Card::ACTIVITIES => [[
                    Activity::TYPE => Activity::TYPE_CARD_OPEN,
                    Activity::USER_ID => 1
                ], [
                    Activity::TYPE => Activity::TYPE_CARD_OPEN,
                    Activity::USER_ID => 2
                ]]
            ], [
                Card::ID => $namedIds['1_ch_prop_2_sh_open'] = 212,
                Card::CHOOSER_ID => 1,
                Card::SHOWNER_ID => 2,
                Card::ACTIVITIES => [[
                    Activity::TYPE => Activity::TYPE_CARD_PROPOSE,
                    Activity::USER_ID => 1
                ], [
                    Activity::TYPE => Activity::TYPE_CARD_OPEN,
                    Activity::USER_ID => 2
                ]]
            ], [
                Card::ID => $namedIds['1_ch_none_2_sh_prop'] = 213,
                Card::CHOOSER_ID => 1,
                Card::SHOWNER_ID => 2,
                Card::ACTIVITIES => [[
                    Activity::TYPE => Activity::TYPE_CARD_FLIP,
                    Activity::USER_ID => 2
                ], [
                    Activity::TYPE => Activity::TYPE_CARD_OPEN,
                    Activity::USER_ID => 2
                ], [
                    Activity::TYPE => Activity::TYPE_CARD_PROPOSE,
                    Activity::USER_ID => 2
                ]]
            ], [
                Card::ID => $namedIds['1_ch_flip_2_sh_prop'] = 214,
                Card::CHOOSER_ID => 1,
                Card::SHOWNER_ID => 2,
                Card::ACTIVITIES => [[
                    Activity::TYPE => Activity::TYPE_CARD_FLIP,
                    Activity::USER_ID => 1
                ], [
                    Activity::TYPE => Activity::TYPE_CARD_PROPOSE,
                    Activity::USER_ID => 2
                ]]
            ], [
                Card::ID => $namedIds['1_ch_open_2_sh_prop'] = 215,
                Card::CHOOSER_ID => 1,
                Card::SHOWNER_ID => 2,
                Card::ACTIVITIES => [[
                    Activity::TYPE => Activity::TYPE_CARD_OPEN,
                    Activity::USER_ID => 1
                ], [
                    Activity::TYPE => Activity::TYPE_CARD_PROPOSE,
                    Activity::USER_ID => 2
                ]]
            ], [
                Card::ID => $namedIds['1_ch_prop_2_sh_prop'] = 216,
                Card::CHOOSER_ID => 1,
                Card::SHOWNER_ID => 2,
                Card::ACTIVITIES => [[
                    Activity::TYPE => Activity::TYPE_CARD_PROPOSE,
                    Activity::USER_ID => 1
                ], [
                    Activity::TYPE => Activity::TYPE_CARD_PROPOSE,
                    Activity::USER_ID => 2
                ]]
            ], [
                Card::ID => $namedIds['2_ch_flip_1_sh_open'] = 217,
                Card::CHOOSER_ID => 2,
                Card::SHOWNER_ID => 1,
                Card::ACTIVITIES => [[
                    Activity::TYPE => Activity::TYPE_CARD_FLIP,
                    Activity::USER_ID => 2
                ], [
                    Activity::TYPE => Activity::TYPE_CARD_OPEN,
                    Activity::USER_ID => 1
                ]]
            ]]
        ]);

        $this->factory(Match::class)->create([
            Match::MAN_ID => $rand ? 3 : 2,
            Match::WOMAN_ID => $rand ? 2 : 3,
            Match::CARDS => [[
                Card::ID => $namedIds['2_ch_flip_3_sh_open'] = 218,
                Card::CHOOSER_ID => 2,
                Card::SHOWNER_ID => 3,
                Card::ACTIVITIES => [[
                    Activity::TYPE => Activity::TYPE_CARD_FLIP,
                    Activity::USER_ID => 2
                ], [
                    Activity::TYPE => Activity::TYPE_CARD_OPEN,
                    Activity::USER_ID => 3
                ]]
            ]]
        ]);


        foreach ( [[ // 0
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_FLIP_STEP,
            CardPagingService::USER_STATUS_CARD_FLIP_STEP,
            ['1_ch_none_2_sh_none']
        ], [ // 1
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_FLIP_STEP,
            CardPagingService::USER_STATUS_CARD_FLIP,
            ['1_ch_none_2_sh_flip', '1_ch_none_2_sh_open', '1_ch_none_2_sh_prop']
        ], [ // 2
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_FLIP_STEP,
            CardPagingService::USER_STATUS_CARD_OPEN_STEP,
            ['1_ch_none_2_sh_flip']
        ], [ // 3
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_FLIP_STEP,
            CardPagingService::USER_STATUS_CARD_OPEN,
            ['1_ch_none_2_sh_open', '1_ch_none_2_sh_prop']
        ], [ // 4
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_FLIP_STEP,
            CardPagingService::USER_STATUS_CARD_PROPOSE_STEP,
            ['1_ch_none_2_sh_open']
        ], [ // 5
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_FLIP_STEP,
            CardPagingService::USER_STATUS_CARD_PROPOSE,
            ['1_ch_none_2_sh_prop']
        ], [ // 6
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_FLIP_STEP,
            CardPagingService::USER_STATUS_ALL,
            ['1_ch_none_2_sh_none', '1_ch_none_2_sh_flip', '1_ch_none_2_sh_open', '1_ch_none_2_sh_prop']
        ], [ // 7
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_FLIP,
            CardPagingService::USER_STATUS_CARD_FLIP_STEP,
            ['1_ch_flip_2_sh_none', '1_ch_open_2_sh_none', '1_ch_prop_2_sh_none']
        ], [ // 8
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_FLIP,
            CardPagingService::USER_STATUS_CARD_FLIP,
            ['1_ch_flip_2_sh_flip', '1_ch_open_2_sh_flip', '1_ch_prop_2_sh_flip', '1_ch_flip_2_sh_open', '1_ch_open_2_sh_open', '1_ch_prop_2_sh_open', '1_ch_flip_2_sh_prop', '1_ch_open_2_sh_prop', '1_ch_prop_2_sh_prop']
        ], [ // 9
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_FLIP,
            CardPagingService::USER_STATUS_CARD_OPEN_STEP,
            ['1_ch_flip_2_sh_flip', '1_ch_open_2_sh_flip', '1_ch_prop_2_sh_flip']
        ], [ // 10
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_FLIP,
            CardPagingService::USER_STATUS_CARD_OPEN,
            ['1_ch_flip_2_sh_open', '1_ch_open_2_sh_open', '1_ch_prop_2_sh_open', '1_ch_flip_2_sh_prop', '1_ch_open_2_sh_prop', '1_ch_prop_2_sh_prop']
        ], [ // 11
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_FLIP,
            CardPagingService::USER_STATUS_CARD_PROPOSE_STEP,
            ['1_ch_flip_2_sh_open', '1_ch_open_2_sh_open', '1_ch_prop_2_sh_open']
        ], [ // 12
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_FLIP,
            CardPagingService::USER_STATUS_CARD_PROPOSE,
            ['1_ch_flip_2_sh_prop', '1_ch_open_2_sh_prop', '1_ch_prop_2_sh_prop']
        ], [ // 13
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_FLIP,
            CardPagingService::USER_STATUS_ALL,
            ['1_ch_flip_2_sh_none', '1_ch_open_2_sh_none', '1_ch_prop_2_sh_none', '1_ch_flip_2_sh_flip', '1_ch_open_2_sh_flip', '1_ch_prop_2_sh_flip', '1_ch_flip_2_sh_open', '1_ch_open_2_sh_open', '1_ch_prop_2_sh_open', '1_ch_flip_2_sh_prop', '1_ch_open_2_sh_prop', '1_ch_prop_2_sh_prop']
        ], [ // 14
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_OPEN_STEP,
            CardPagingService::USER_STATUS_CARD_FLIP_STEP,
            ['1_ch_flip_2_sh_none']
        ], [ // 15
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_OPEN_STEP,
            CardPagingService::USER_STATUS_CARD_FLIP,
            ['1_ch_flip_2_sh_flip', '1_ch_flip_2_sh_open', '1_ch_flip_2_sh_prop']
        ], [ // 16
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_OPEN_STEP,
            CardPagingService::USER_STATUS_CARD_OPEN_STEP,
            ['1_ch_flip_2_sh_flip']
        ], [ // 17
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_OPEN_STEP,
            CardPagingService::USER_STATUS_CARD_OPEN,
            ['1_ch_flip_2_sh_open', '1_ch_flip_2_sh_prop']
        ], [ // 18
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_OPEN_STEP,
            CardPagingService::USER_STATUS_CARD_PROPOSE_STEP,
            ['1_ch_flip_2_sh_open']
        ], [ // 19
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_OPEN_STEP,
            CardPagingService::USER_STATUS_CARD_PROPOSE,
            ['1_ch_flip_2_sh_prop']
        ], [ // 20
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_OPEN_STEP,
            CardPagingService::USER_STATUS_ALL,
            ['1_ch_flip_2_sh_none', '1_ch_flip_2_sh_flip', '1_ch_flip_2_sh_open', '1_ch_flip_2_sh_prop']
        ], [ // 21
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_OPEN,
            CardPagingService::USER_STATUS_CARD_FLIP_STEP,
            ['1_ch_open_2_sh_none', '1_ch_prop_2_sh_none']
        ], [ // 22
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_OPEN,
            CardPagingService::USER_STATUS_CARD_FLIP,
            ['1_ch_open_2_sh_flip', '1_ch_prop_2_sh_flip', '1_ch_open_2_sh_open', '1_ch_prop_2_sh_open', '1_ch_open_2_sh_prop', '1_ch_prop_2_sh_prop']
        ], [ // 23
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_OPEN,
            CardPagingService::USER_STATUS_CARD_OPEN_STEP,
            ['1_ch_open_2_sh_flip', '1_ch_prop_2_sh_flip']
        ], [ // 24
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_OPEN,
            CardPagingService::USER_STATUS_CARD_OPEN,
            ['1_ch_open_2_sh_open', '1_ch_prop_2_sh_open', '1_ch_open_2_sh_prop', '1_ch_prop_2_sh_prop']
        ], [ // 25
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_OPEN,
            CardPagingService::USER_STATUS_CARD_PROPOSE_STEP,
            ['1_ch_open_2_sh_open', '1_ch_prop_2_sh_open']
        ], [ // 26
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_OPEN,
            CardPagingService::USER_STATUS_CARD_PROPOSE,
            ['1_ch_open_2_sh_prop', '1_ch_prop_2_sh_prop']
        ], [ // 27
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_OPEN,
            CardPagingService::USER_STATUS_ALL,
            ['1_ch_open_2_sh_none', '1_ch_prop_2_sh_none', '1_ch_open_2_sh_flip', '1_ch_prop_2_sh_flip', '1_ch_open_2_sh_open', '1_ch_prop_2_sh_open', '1_ch_open_2_sh_prop', '1_ch_prop_2_sh_prop']
        ], [ // 28
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_PROPOSE_STEP,
            CardPagingService::USER_STATUS_CARD_FLIP_STEP,
            ['1_ch_open_2_sh_none']
        ], [ // 29
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_PROPOSE_STEP,
            CardPagingService::USER_STATUS_CARD_FLIP,
            ['1_ch_open_2_sh_flip', '1_ch_open_2_sh_open', '1_ch_open_2_sh_prop']
        ], [ // 30
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_PROPOSE_STEP,
            CardPagingService::USER_STATUS_CARD_OPEN_STEP,
            ['1_ch_open_2_sh_flip']
        ], [ // 31
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_PROPOSE_STEP,
            CardPagingService::USER_STATUS_CARD_OPEN,
            ['1_ch_open_2_sh_open', '1_ch_open_2_sh_prop']
        ], [ // 32
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_PROPOSE_STEP,
            CardPagingService::USER_STATUS_CARD_PROPOSE_STEP,
            ['1_ch_open_2_sh_open']
        ], [ // 33
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_PROPOSE_STEP,
            CardPagingService::USER_STATUS_CARD_PROPOSE,
            ['1_ch_open_2_sh_prop']
        ], [ // 34
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_PROPOSE_STEP,
            CardPagingService::USER_STATUS_ALL,
            ['1_ch_open_2_sh_none', '1_ch_open_2_sh_flip', '1_ch_open_2_sh_open', '1_ch_open_2_sh_prop']
        ], [ // 35
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_PROPOSE,
            CardPagingService::USER_STATUS_CARD_FLIP_STEP,
            ['1_ch_prop_2_sh_none']
        ], [ // 36
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_PROPOSE,
            CardPagingService::USER_STATUS_CARD_FLIP,
            ['1_ch_prop_2_sh_flip', '1_ch_prop_2_sh_open', '1_ch_prop_2_sh_prop']
        ], [ // 37
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_PROPOSE,
            CardPagingService::USER_STATUS_CARD_OPEN_STEP,
            ['1_ch_prop_2_sh_flip']
        ], [ // 38
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_PROPOSE,
            CardPagingService::USER_STATUS_CARD_OPEN,
            ['1_ch_prop_2_sh_open', '1_ch_prop_2_sh_prop']
        ], [ // 39
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_PROPOSE,
            CardPagingService::USER_STATUS_CARD_PROPOSE_STEP,
            ['1_ch_prop_2_sh_open']
        ], [ // 40
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_PROPOSE,
            CardPagingService::USER_STATUS_CARD_PROPOSE,
            ['1_ch_prop_2_sh_prop']
        ], [ // 41
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_PROPOSE,
            CardPagingService::USER_STATUS_ALL,
            ['1_ch_prop_2_sh_none', '1_ch_prop_2_sh_flip', '1_ch_prop_2_sh_open', '1_ch_prop_2_sh_prop']
        ], [ // 42
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_ALL,
            CardPagingService::USER_STATUS_CARD_FLIP_STEP,
            ['1_ch_none_2_sh_none', '1_ch_flip_2_sh_none', '1_ch_open_2_sh_none', '1_ch_prop_2_sh_none']
        ], [ // 43
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_ALL,
            CardPagingService::USER_STATUS_CARD_FLIP,
            ['1_ch_none_2_sh_flip', '1_ch_flip_2_sh_flip', '1_ch_open_2_sh_flip', '1_ch_prop_2_sh_flip', '1_ch_none_2_sh_open', '1_ch_flip_2_sh_open', '1_ch_open_2_sh_open', '1_ch_prop_2_sh_open', '1_ch_none_2_sh_prop', '1_ch_flip_2_sh_prop', '1_ch_open_2_sh_prop', '1_ch_prop_2_sh_prop']
        ], [ // 44
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_ALL,
            CardPagingService::USER_STATUS_CARD_OPEN_STEP,
            ['1_ch_none_2_sh_flip', '1_ch_flip_2_sh_flip', '1_ch_open_2_sh_flip', '1_ch_prop_2_sh_flip']
        ], [ // 45
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_ALL,
            CardPagingService::USER_STATUS_CARD_OPEN,
            ['1_ch_none_2_sh_open', '1_ch_flip_2_sh_open', '1_ch_open_2_sh_open', '1_ch_prop_2_sh_open', '1_ch_none_2_sh_prop', '1_ch_flip_2_sh_prop', '1_ch_open_2_sh_prop', '1_ch_prop_2_sh_prop']
        ], [ // 46
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_ALL,
            CardPagingService::USER_STATUS_CARD_PROPOSE_STEP,
            ['1_ch_none_2_sh_open', '1_ch_flip_2_sh_open', '1_ch_open_2_sh_open', '1_ch_prop_2_sh_open']
        ], [ // 47
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_ALL,
            CardPagingService::USER_STATUS_CARD_PROPOSE,
            ['1_ch_none_2_sh_prop', '1_ch_flip_2_sh_prop', '1_ch_open_2_sh_prop', '1_ch_prop_2_sh_prop']
        ], [ // 48
            1,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_ALL,
            CardPagingService::USER_STATUS_ALL,
            ['1_ch_none_2_sh_none', '1_ch_flip_2_sh_none', '1_ch_open_2_sh_none', '1_ch_prop_2_sh_none', '1_ch_none_2_sh_flip', '1_ch_flip_2_sh_flip', '1_ch_open_2_sh_flip', '1_ch_prop_2_sh_flip', '1_ch_none_2_sh_open', '1_ch_flip_2_sh_open', '1_ch_open_2_sh_open', '1_ch_prop_2_sh_open', '1_ch_none_2_sh_prop', '1_ch_flip_2_sh_prop', '1_ch_open_2_sh_prop', '1_ch_prop_2_sh_prop']
        ], [ // 49
            1,
            CardPagingService::CARD_TYPE_SHOWNER,
            CardPagingService::USER_STATUS_ALL,
            CardPagingService::USER_STATUS_ALL,
            ['2_ch_flip_1_sh_open']
        ], [ // 50
            1,
            CardPagingService::CARD_TYPE_BOTH,
            CardPagingService::USER_STATUS_ALL,
            CardPagingService::USER_STATUS_ALL,
            ['1_ch_none_2_sh_none', '1_ch_flip_2_sh_none', '1_ch_open_2_sh_none', '1_ch_prop_2_sh_none', '1_ch_none_2_sh_flip', '1_ch_flip_2_sh_flip', '1_ch_open_2_sh_flip', '1_ch_prop_2_sh_flip', '1_ch_none_2_sh_open', '1_ch_flip_2_sh_open', '1_ch_open_2_sh_open', '1_ch_prop_2_sh_open', '1_ch_none_2_sh_prop', '1_ch_flip_2_sh_prop', '1_ch_open_2_sh_prop', '1_ch_prop_2_sh_prop', '2_ch_flip_1_sh_open']
        ], [ // 51
            2,
            CardPagingService::CARD_TYPE_CHOOSER,
            CardPagingService::USER_STATUS_CARD_OPEN_STEP,
            CardPagingService::USER_STATUS_CARD_PROPOSE_STEP,
            ['2_ch_flip_1_sh_open', '2_ch_flip_3_sh_open']
        ], [ // 52
            2,
            CardPagingService::CARD_TYPE_BOTH,
            CardPagingService::USER_STATUS_CARD_OPEN_STEP,
            CardPagingService::USER_STATUS_CARD_PROPOSE_STEP,
            ['1_ch_open_2_sh_flip', '2_ch_flip_1_sh_open', '2_ch_flip_3_sh_open']
        ]] as $i => $args )
        {
            $this->when(function () use ($args, $namedIds) {

                $authUser = User::find($args[0]);
                $cardType = $args[1];
                $authUserStatus = $args[2];
                $matchingUserStatus = $args[3];
                $expectIds = array_values(array_only($namedIds, $args[4]));

                auth()->setUser($authUser);
                request()->offsetSet('card_type', $cardType);
                request()->offsetSet('auth_user_status', $authUserStatus);
                request()->offsetSet('matching_user_status', $matchingUserStatus);
                request()->offsetSet('limit', 100);

                $this->assertResultWithPaging($expectIds);
            });
        }
    }

    public function testShow()
    {
        $this->factory(User::class)->create(['id' => 1]);
        $this->factory(User::class)->create(['id' => 2]);
        $this->factory(User::class)->create(['id' => 3]);
        $this->factory(Card::class)->create(['id' => 11, 'chooser_id' => 1, 'showner_id' => 2]);
        $this->factory(Card::class)->create(['id' => 12, 'chooser_id' => 3, 'showner_id' => 2]);

        $this->when(function () {

            auth()->setUser(User::find(1));
            request()->offsetSet('id', 11);

            $this->assertResultWithFinding(11);
        });

        $this->when(function () {

            auth()->setUser(User::find(2));
            request()->offsetSet('id', 11);

            $this->assertResultWithFinding(11);
        });

        $this->when(function () {

            auth()->setUser(User::find(2));
            request()->offsetSet('id', 12);

            $this->assertResultWithFinding(12);
        });
    }

    public function testShowErrorIntegerRuleId()
    {
        $this->when(function () {

            request()->offsetSet('id', 'abcd');

            $this->assertError('[id] must be an integer.');
        });

        $this->when(function () {

            request()->offsetSet('id', 'abcd');

            $this->assertError('[id] must be an integer.');
        });
    }

    public function testShowErrorNotNullRuleModel()
    {
        $this->when(function () {

            $this->factory(Card::class)->create(['id' => 11]);
            $this->factory(Card::class)->create(['id' => 12]);

            request()->offsetSet('id', 13);

            $this->assertError('card for [id] must exist.');
        });
    }

    public function testShowErrorRequiredRuleAuthUser()
    {
        $this->when(function () {

            $this->assertError('authorized user is required.');
        });
    }

    public function testShowErrorRequiredRuleId()
    {
        $this->when(function () {

            $this->assertError('[id] is required.');
        });
    }

    public function testShowErrorRequiredRulePermittedUser()
    {
        $this->factory(User::class)->create(['id' => 1]);
        $this->factory(User::class)->create(['id' => 2]);
        $this->factory(User::class)->create(['id' => 3]);
        $this->factory(Card::class)->create(['id' => 11, 'chooser_id' => 1, 'showner_id' => 2]);
        $this->factory(Card::class)->create(['id' => 12, 'chooser_id' => 3, 'showner_id' => 2]);

        $this->when(function () {

            auth()->setUser(User::find(3));

            request()->offsetSet('id', 11);

            $this->assertError('authorized user who is related user of card for [id] is required.');
        });

        $this->when(function () {

            auth()->setUser(User::find(1));

            request()->offsetSet('id', 12);

            $this->assertError('authorized user who is related user of card for [id] is required.');
        });
    }

}
