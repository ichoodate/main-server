<?php

namespace Tests\Unit\App\Http\Controllers\Api;

use App\Database\Models\User;
use App\Database\Models\FacePhoto;
use Tests\Unit\App\Http\Controllers\Api\_TestCase;

class FacePhotoControllerTest extends _TestCase {

    public function testIndex()
    {
        $this->factory(User::class)->create(['id' => 1]);
        $this->factory(User::class)->create(['id' => 2]);
        $this->factory(FacePhoto::class)->create(['id' => 11, 'user_id' => 1]);
        $this->factory(FacePhoto::class)->create(['id' => 12, 'user_id' => 1]);
        $this->factory(FacePhoto::class)->create(['id' => 13, 'user_id' => 2]);
        $this->factory(FacePhoto::class)->create(['id' => 14, 'user_id' => 2]);

        $this->when(function () {

            auth()->setUser(User::find(1));

            $this->assertResultWithListing([11, 12]);
        });

        $this->when(function () {

            auth()->setUser(User::find(2));

            $this->assertResultWithListing([13, 14]);
        });
    }

    public function testIndexErrorRequiredRuleAuthUser()
    {
        $this->when(function () {

            $this->assertError('authorized user is required.');
        });
    }

    public function testStore()
    {
        $this->factory(User::class)->create(['id' => 1]);
        $this->factory(User::class)->create(['id' => 2]);

        $this->factory(FacePhoto::class)->create(['id' => 11, 'user_id' => 1]);

        $this->when(function () {

            auth()->setUser(User::find(1));
            request()->offsetSet('upload', 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPj/HwADBwIAMCbHYQAAAABJRU5ErkJggg==');

            $this->assertResultWithPersisting(new FacePhoto([
                'user_id' => 1,
                'data' => 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPj/HwADBwIAMCbHYQAAAABJRU5ErkJggg=='
            ]));
        });
    }

    public function testStoreErrorBase64ImageRuleUpload()
    {
        $this->factory(User::class)->create(['id' => 1]);

        $this->when(function () {

            auth()->setUser(User::find(1));
            request()->offsetSet('upload', 'asiudfh9w=8uihf');

            $this->assertError('[upload] must to be base64 image string.');
        });
    }

    public function testStoreErrorRequiredRuleAuthUser()
    {
        $this->when(function () {

            $this->assertError('authorized user is required.');
        });
    }

    public function testStoreErrorRequiredRuleUpload()
    {
        $this->when(function () {

            $this->assertError('[upload] is required.');
        });
    }

    public function testShow()
    {
        $this->factory(User::class)->create(['id' => 1]);
        $this->factory(User::class)->create(['id' => 2]);
        $this->factory(FacePhoto::class)->create(['id' => 11, 'user_id' => 1]);
        $this->factory(FacePhoto::class)->create(['id' => 12, 'user_id' => 2]);

        $this->when(function () {

            auth()->setUser(User::find(1));
            request()->offsetSet('id', 11);

            $this->assertResultWithFinding(11);
        });

        $this->when(function () {

            auth()->setUser(User::find(2));
            request()->offsetSet('id', 12);

            $this->assertResultWithFinding(12);
        });
    }

    public function testShowErrorIntegerRuleId()
    {
        $this->when(function () {

            request()->offsetSet('id', [11]);

            $this->assertError('[id] must be an integer.');
        });

        $this->when(function () {

            request()->offsetSet('id', 'abcd');

            $this->assertError('[id] must be an integer.');
        });
    }

    public function testShowErrorNotNullRuleModel()
    {
        $this->when(function () {

            $this->factory(FacePhoto::class)->create(['id' => 11]);
            $this->factory(FacePhoto::class)->create(['id' => 12]);

            request()->offsetSet('id', 13);

            $this->assertError('face_photo for [id] must exist.');
        });
    }

    public function testShowErrorRequiredRuleAuthUser()
    {
        $this->when(function () {

            $this->assertError('authorized user is required.');
        });
    }

    public function testShowErrorRequiredRuleId()
    {
        $this->when(function () {

            $this->assertError('[id] is required.');
        });
    }

    public function testShowRequiredRulePermittedUser()
    {
        $this->when(function () {

            $this->factory(User::class)->create(['id' => 1]);
            $this->factory(FacePhoto::class)->create(['id' => 11, 'user_id' => 2]);

            auth()->setUser(User::find(1));
            request()->offsetSet('id', 11);

            $this->assertError('authorized user who is related user of face_photo for [id] is required.');
        });
    }

}
