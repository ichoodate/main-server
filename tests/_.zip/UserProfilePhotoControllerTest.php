<?php

namespace Tests\Unit\App\Http\Controllers\Api;

use App\Database\Models\ProfilePhoto;
use App\Database\Models\User;
use Illuminate\Support\Facades\Route;

class UserProfilePhotoControllerTest extends _TestCase {

    public function testIndex()
    {
        dd(redirect()->action('Api\UserProfilePhotoController@index', [11111]));
        // $this->factory(User::class)->create(['id' => 1]);
        // $this->factory(User::class)->create(['id' => 2]);
        // $this->factory(User::class)->create(['id' => 3]);
        // $this->factory(ProfilePhoto::class)->create(['id' => 11, 'user_id' => 1]);
        // $this->factory(ProfilePhoto::class)->create(['id' => 12, 'user_id' => 1]);
        // $this->factory(ProfilePhoto::class)->create(['id' => 13, 'user_id' => 2]);
        // $this->factory(ProfilePhoto::class)->create(['id' => 14, 'user_id' => 2]);
        // $this->factory(ProfilePhoto::class)->create(['id' => 15, 'user_id' => 3]);
        // $this->factory(ProfilePhoto::class)->create(['id' => 16, 'user_id' => 3]);

        // $this->when(function () {

        //     auth()->setUser(User::find(1));

        //     $this->assertResultWithListing([11, 12]);
        // });

        // $this->when(function () {

        //     auth()->setUser(User::find(2));

        //     $this->assertResultWithListing([13, 14]);
        // });

        // $this->when(function () {

        //     auth()->setUser(User::find(3));

        //     $this->assertResultWithListing([15, 16]);
        // });
    }

}
