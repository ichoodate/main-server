<?php

namespace Tests\Unit\App\Http\Controllers\Api;

use App\Database\Models\Activity;
use App\Database\Models\Card;
use App\Database\Models\Coin;
use App\Database\Models\User;
use Tests\Unit\App\Http\Controllers\Api\_TestCase;

class CardActivityControllerTest extends _TestCase {

    public function defaultForIndex()
    {
        return [];
    }

    public function defaultForPost()
    {
        return [
            'card_id'  => $this->faker->randomNumber(),
            'timezone' => $this->faker->timezone,
            'type'     => $this->faker->randomElement([Activity::TYPE_CARD_FLIP])
        ];
    }

    public function testIndex()
    {
        $this->factory(User::class)->create(['id' => 1]);
        $this->factory(User::class)->create(['id' => 2]);
        $this->factory(Card::class)->create(['id' => 11, 'chooser_id' => 1, 'showner_id' => 2]);
        $this->factory(Card::class)->create(['id' => 12, 'chooser_id' => 3, 'showner_id' => 4]);
        $this->factory(Activity::class)->create(['id' => 101, 'user_id' => 1, 'related_id' => 11]);
        $this->factory(Activity::class)->create(['id' => 102, 'user_id' => 2, 'related_id' => 11]);
        $this->factory(Activity::class)->create(['i3' => 103, 'user_id' => 3, 'related_id' => 12]);

        $this->when(function () {

            auth()->setUser(User::find(1));
            request()->offsetSet('card_id', 11);

            $this->assertResultWithListing([101, 102]);
        });

        $this->when(function () {

            auth()->setUser(User::find(2));
            request()->offsetSet('card_id', 11);

            $this->assertResultWithListing([101, 102]);
        });
    }

    public function testIndexErrorIntegerRuleCardId()
    {
        $this->when(function () {

            request()->offsetSet('card_id', [11]);

            $this->assertError('[card_id] must be an integer.');
        });
    }

    public function testIndexErrorNotNullRuleCardModel()
    {
        $this->when(function () {

            $this->factory(User::class)->create(['id' => 1]);

            auth()->setUser(User::find(1));
            request()->offsetSet('card_id', 1234);

            $this->assertError('card for [card_id] must exist.');
        });
    }

    public function testIndexErrorRequiredRuleAuthUser()
    {
        $this->when(function () {

            $this->assertError('authorized user is required.');
        });
    }

    public function testIndexErrorRequiredRuleCardId()
    {
        $this->when(function () {

            $this->assertError('[card_id] is required.');
        });
    }

    public function testIndexErrorRequiredRulePermittedUser()
    {
        $this->when(function () {

            $this->factory(User::class)->create(['id' => 3]);
            $this->factory(Card::class)->create(['id' => 11, 'chooser_id' => 1, 'showner_id' => 2]);

            auth()->setUser(User::find(3));
            request()->offsetSet('card_id', 11);

            $this->assertError('authorized user who is related user of card for [card_id] is required.');
        });
    }

    public function testStore()
    {
        $this->factory(User::class)->create(['id' => 1]);
        $this->factory(User::class)->create(['id' => 2]);
        $this->factory(Card::class)->create(['id' => 11, 'match_id' => 1234, 'chooser_id' => 1, 'showner_id' => 2, 'created_at' => '2000-01-01 11:22:33']);

        auth()->setUser(User::find(1));
        $this->setInput('card_id', 11);
        $this->setInputDefault();

        $this->when(function () {

            request()->offsetSet('type', Activity::TYPE_CARD_FLIP);

            $this->assertResultWithPersisting(new Activity([
                'user_id'    => 1,
                'related_id' => 11,
                'type'       => Activity::TYPE_CARD_FLIP
            ]));
            $this->assertPersistence(new Coin([
                'user_id'    => 1,
                'related_id' => $this->result->getKey()
            ]));
        });

        $this->factory(Activity::class)->create(['id' => 101, 'user_id' => 1, 'related_id' => 11, 'type' => Activity::TYPE_CARD_FLIP]);

        $this->when(function () {

            request()->offsetSet('type', Activity::TYPE_CARD_OPEN);

            $this->assertResultWithPersisting(new Activity([
                'user_id'    => 1,
                'related_id' => 11,
                'type'       => Activity::TYPE_CARD_OPEN
            ]));
            $this->assertPersistence(new Activity([
                'user_id'    => 1,
                'related_id' => 1234,
                'type'       => Activity::TYPE_MATCH_OPEN
            ]));
        });

        $this->factory(Activity::class)->create(['id' => 102, 'user_id' => 1, 'related_id' => 1234, 'type' => Activity::TYPE_MATCH_OPEN]);

        $this->when(function () {

            request()->offsetSet('type', Activity::TYPE_CARD_PROPOSE);

            $this->assertResultWithPersisting(new Activity([
                'user_id'    => 1,
                'related_id' => 11,
                'type'       => Activity::TYPE_CARD_PROPOSE
            ]));
            $this->assertPersistence(new Activity([
                'user_id'    => 1,
                'related_id' => 1234,
                'type'       => Activity::TYPE_MATCH_PROPOSE
            ]));
        });
    }

    public function testStoreErrorInRuleType()
    {
        $this->when(function () {

            request()->offsetSet('type', 'aaaa');

            $this->assertError('[type] is invalid.');
        });
    }

    public function testStoreErrorNotNullRuleCardFlip()
    {
        $this->when(function () {

            $this->factory(User::class)->create(['id' => 1]);
            $this->factory(Card::class)->create(['id' => 11, 'match_id' => 1234, 'chooser_id' => 1, 'showner_id' => 2]);

            auth()->setUser(User::find(1));
            request()->offsetSet('card_id', 11);
            request()->offsetSet('type', Activity::TYPE_CARD_OPEN);
            $this->setInputDefault();

            $this->assertError('flip status acted by authorized user for card for [card_id] must exist.');
        });
    }

    public function testStoreErrorNotNullRuleMatchOpen()
    {
        $this->when(function () {

            $this->factory(User::class)->create(['id' => 1]);
            $this->factory(Card::class)->create(['id' => 11, 'match_id' => 1234, 'chooser_id' => 1, 'showner_id' => 2]);

            auth()->setUser(User::find(1));
            request()->offsetSet('card_id', 11);
            request()->offsetSet('type', Activity::TYPE_CARD_PROPOSE);
            $this->setInputDefault();

            $this->assertError('profile open status acted by matching users of card for [card_id] must exist.');
        });
    }

    public function testStoreErrorNullRuleCardFlip()
    {
        $this->when(function () {

            $this->factory(User::class)->create(['id' => 1]);
            $this->factory(Card::class)->create(['id' => 11, 'match_id' => 1234, 'chooser_id' => 1, 'showner_id' => 2]);
            $this->factory(Activity::class)->create(['id' => 101, 'user_id' => 1, 'related_id' => 11, 'type' => Activity::TYPE_CARD_FLIP]);

            auth()->setUser(User::find(1));
            request()->offsetSet('card_id', 11);
            request()->offsetSet('type', Activity::TYPE_CARD_FLIP);
            $this->setInputDefault();

            $this->assertError('flip status acted by authorized user for card for [card_id] must not exist.');
        });
    }

    public function testStoreErrorNullRuleMatchOpen()
    {
        $this->when(function () {

            $this->factory(User::class)->create(['id' => 1]);
            $this->factory(Card::class)->create(['id' => 11, 'match_id' => 1234, 'chooser_id' => 1, 'showner_id' => 2]);
            $this->factory(Activity::class)->create(['id' => 101, 'user_id' => 1, 'related_id' => 1234, 'type' => Activity::TYPE_MATCH_OPEN]);

            auth()->setUser(User::find(1));
            request()->offsetSet('card_id', 11);
            request()->offsetSet('type', Activity::TYPE_CARD_OPEN);
            $this->setInputDefault();

            $this->assertError('profile open status acted by matching users of card for [card_id] must not exist.');
        });
    }

    public function testStoreErrorNullRuleMatchPropose()
    {
        $this->when(function () {

            $this->factory(User::class)->create(['id' => 1]);
            $this->factory(Card::class)->create(['id' => 11, 'match_id' => 1234, 'chooser_id' => 1, 'showner_id' => 2]);
            $this->factory(Activity::class)->create(['id' => 101, 'user_id' => 1, 'related_id' => 1234, 'type' => Activity::TYPE_MATCH_PROPOSE]);

            auth()->setUser(User::find(1));
            request()->offsetSet('card_id', 11);
            request()->offsetSet('type', Activity::TYPE_CARD_PROPOSE);
            $this->setInputDefault();

            $this->assertError('propose status acted by matching users of card for [card_id] must not exist.');
        });
    }

    public function testStoreErrorRequiredRuleAuthUser()
    {
        $this->when(function () {

            $this->assertError('authorized user is required.');
        });
    }

    public function testStoreErrorRequiredRuleCardId()
    {
        $this->when(function () {

            $this->assertError('[card_id] is required.');
        });
    }

    public function testStoreErrorRequiredRuleTimezone()
    {
        $this->when(function () {

            $this->assertError('[timezone] is required.');
        });
    }

    public function testStoreErrorRequiredRuleType()
    {
        $this->when(function () {

            $this->assertError('[type] is required.');
        });
    }

}
