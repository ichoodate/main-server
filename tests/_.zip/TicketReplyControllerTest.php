<?php

namespace Tests\Unit\App\Http\Controllers\Api;

use App\Database\Models\Reply;
use App\Database\Models\Role;
use App\Database\Models\Ticket;
use App\Database\Models\User;
use Tests\Unit\App\Http\Controllers\Api\_TestCase;

class TicketReplyControllerTest extends _TestCase {

    public function testIndex()
    {
        $this->factory(User::class)->create(['id' => 1]);
        $this->factory(User::class)->create(['id' => 2]);
        $this->factory(User::class)->create(['id' => 3]);
        $this->factory(User::class)->create(['id' => 4]);
        $this->factory(User::class)->create(['id' => 5]);
        $this->factory(User::class)->create(['id' => 6]);
        $this->factory(Role::class)->create(['type' => Role::TYPE_ADMIN, 'user_id' => 1]);
        $this->factory(Ticket::class)->create(['id' => 11, 'writer_id' => 1]);
        $this->factory(Ticket::class)->create(['id' => 12, 'writer_id' => 2]);
        $this->factory(Ticket::class)->create(['id' => 13, 'writer_id' => 3]);
        $this->factory(Reply::class)->create(['id' => 101, 'ticket_id' => 11]);
        $this->factory(Reply::class)->create(['id' => 102, 'ticket_id' => 11]);
        $this->factory(Reply::class)->create(['id' => 103, 'ticket_id' => 12]);
        $this->factory(Reply::class)->create(['id' => 104, 'ticket_id' => 12]);
        $this->factory(Reply::class)->create(['id' => 105, 'ticket_id' => 13]);
        $this->factory(Reply::class)->create(['id' => 106, 'ticket_id' => 13]);

        $this->when(function () {

            auth()->setUser(User::find(1));
            request()->offsetSet('ticket_id', 11);

            $this->assertResultWithListing([101, 102]);
        });

        $this->when(function () {

            auth()->setUser(User::find(1));
            request()->offsetSet('ticket_id', 12);

            $this->assertResultWithListing([103, 104]);
        });

        $this->when(function () {

            auth()->setUser(User::find(2));
            request()->offsetSet('ticket_id', 12);

            $this->assertResultWithListing([103, 104]);
        });

        $this->when(function () {

            auth()->setUser(User::find(3));
            request()->offsetSet('ticket_id', 13);

            $this->assertResultWithListing([105, 106]);
        });
    }

    public function testIndexErrorRequiredRuleAuthUser()
    {
        $this->when(function () {

            $this->assertError('authorized user is required.');
        });
    }

    public function testIndexErrorRequiredRuleTicketId()
    {
        $this->when(function () {

            $this->assertError('[ticket_id] is required.');
        });
    }

    public function testIndexErrorRequiredRulePermittedUser()
    {
        $this->factory(User::class)->create(['id' => 1]);
        $this->factory(Ticket::class)->create(['id' => 11, 'writer_id' => 2]);

        $this->when(function () {

            auth()->setUser(User::find(1));
            request()->offsetSet('ticket_id', 11);

            $this->assertError('authorized user who is related user of ticket for [ticket_id] is required.');
        });
    }

    public function testStore()
    {
        $this->factory(User::class)->create(['id' => 1]);
        $this->factory(User::class)->create(['id' => 2]);
        $this->factory(User::class)->create(['id' => 3]);
        $this->factory(Role::class)->create(['type' => Role::TYPE_ADMIN, 'user_id' => 1]);
        $this->factory(Ticket::class)->create(['id' => 11, 'writer_id' => 2]);
        $this->factory(Ticket::class)->create(['id' => 12, 'writer_id' => 3]);

        $this->when(function () {

            auth()->setUser(User::find(2));
            request()->offsetSet('ticket_id', 11);
            request()->offsetSet('description', 'some content');

            $this->assertResultWithPersisting(new Reply([
                Reply::TICKET_ID
                    => 11,
                Reply::WRITER_ID
                    => 2,
                Reply::DESCRIPTION
                    => 'some content'
            ]));
        });

        $this->when(function () {

            auth()->setUser(User::find(1));
            request()->offsetSet('ticket_id', 11);
            request()->offsetSet('description', 'some content');

            $this->assertResultWithPersisting(new Reply([
                Reply::TICKET_ID
                    => 11,
                Reply::WRITER_ID
                    => 1,
                Reply::DESCRIPTION
                    => 'some content'
            ]));
        });
    }

}
