<?php

namespace Tests\Unit\App\Http\Controllers\Api;

use App\Database\Models\Card;
use App\Database\Models\CardGroup;
use App\Database\Models\User;
use Tests\Unit\App\Http\Controllers\Api\_TestCase;

class CardGroupCardControllerTest extends _TestCase {

    public function testIndex()
    {
        $this->factory(User::class)->create(['id' => 1, 'gender' => User::GENDER_MAN]);
        $this->factory(User::class)->create(['id' => 2, 'gender' => User::GENDER_WOMAN]);
        $this->factory(User::class)->create(['id' => 3, 'gender' => User::GENDER_MAN]);
        $this->factory(User::class)->create(['id' => 4, 'gender' => User::GENDER_WOMAN]);
        $this->factory(User::class)->create(['id' => 5, 'gender' => User::GENDER_MAN]);
        $this->factory(User::class)->create(['id' => 6, 'gender' => User::GENDER_WOMAN]);
        $this->factory(CardGroup::class)->create(['id' => 11, 'user_id' => 1]);
        $this->factory(CardGroup::class)->create(['id' => 12, 'user_id' => 2]);
        $this->factory(CardGroup::class)->create(['id' => 13, 'user_id' => 3]);
        $this->factory(Card::class)->create(['id' => 101, 'group_id' => 11, 'chooser_id' => 1, 'showner_id' => 2]);
        $this->factory(Card::class)->create(['id' => 102, 'group_id' => 11, 'chooser_id' => 1, 'showner_id' => 4]);
        $this->factory(Card::class)->create(['id' => 103, 'group_id' => 12, 'chooser_id' => 2, 'showner_id' => 3]);
        $this->factory(Card::class)->create(['id' => 104, 'group_id' => 12, 'chooser_id' => 2, 'showner_id' => 5]);
        $this->factory(Card::class)->create(['id' => 105, 'group_id' => 13, 'chooser_id' => 3, 'showner_id' => 4]);
        $this->factory(Card::class)->create(['id' => 106, 'group_id' => 13, 'chooser_id' => 3, 'showner_id' => 6]);

        $this->when(function () {

            auth()->setUser(User::find(1));
            request()->offsetSet('card_group_id', 11);

            $this->assertResultWithListing([101, 102]);
        });

        $this->when(function () {

            auth()->setUser(User::find(2));
            request()->offsetSet('card_group_id', 12);

            $this->assertResultWithListing([103, 104]);
        });

        $this->when(function () {

            auth()->setUser(User::find(3));
            request()->offsetSet('card_group_id', 13);

            $this->assertResultWithListing([105, 106]);
        });
    }

    public function testIndexErrorRequiredRuleAuthUser()
    {
        $this->when(function () {

            $this->assertError('authorized user is required.');
        });
    }

    public function testIndexErrorRequiredRuleCardGroupId()
    {
        $this->when(function () {

            $this->assertError('[card_group_id] is required.');
        });
    }

    public function testIndexErrorRequiredRulePermittedUser()
    {
        $this->factory(User::class)->create(['id' => 1, 'gender' => User::GENDER_MAN]);
        $this->factory(CardGroup::class)->create(['id' => 11, 'user_id' => 2]);

        $this->when(function () {

            auth()->setUser(User::find(1));
            request()->offsetSet('card_group_id', 11);

            $this->assertError('authorized user who is related user of card_group for [card_group_id] is required.');
        });
    }

}
