<?php

namespace Tests\Unit\App\Http\Controllers\Api;

use App\Database\Models\Activity;
use App\Database\Models\User;
use Tests\Unit\App\Http\Controllers\Api\_TestCase;

class ActivityControllerTest extends _TestCase {

    public function testShow()
    {
        $this->factory(User::class)->create(['id' => 1]);
        $this->factory(User::class)->create(['id' => 2]);
        $this->factory(Activity::class)->create(['id' => 11, 'user_id' => 1]);
        $this->factory(Activity::class)->create(['id' => 12, 'user_id' => 2]);

        $this->when(function () {

            auth()->setUser(User::find(1));
            request()->offsetSet('id', 11);

            $this->assertResultWithFinding(11);
        });

        $this->when(function () {

            auth()->setUser(User::find(2));
            request()->offsetSet('id', 12);

            $this->assertResultWithFinding(12);
        });
    }

    public function testShowErrorIntegerRuleId()
    {
        $this->when(function () {

            request()->offsetSet('id', [11]);

            $this->assertError('[id] must be an integer.');
        });

        $this->when(function () {

            request()->offsetSet('id', 'abcd');

            $this->assertError('[id] must be an integer.');
        });
    }

    public function testShowErrorNotNullRuleModel()
    {
        $this->when(function () {

            $this->factory(Activity::class)->create(['id' => 11]);
            $this->factory(Activity::class)->create(['id' => 12]);

            request()->offsetSet('id', 13);

            $this->assertError('activity for [id] must exist.');
        });
    }

    public function testShowErrorRequiredRuleAuthUser()
    {
        $this->when(function () {

            $this->assertError('authorized user is required.');
        });
    }

    public function testShowErrorRequiredRuleId()
    {
        $this->when(function () {

            $this->assertError('[id] is required.');
        });
    }

    public function testShowErrorRequiredRulePermittedUser()
    {
        $this->factory(User::class)->create(['id' => 1]);
        $this->factory(User::class)->create(['id' => 2]);
        $this->factory(Activity::class)->create(['id' => 11, 'user_id' => 1]);
        $this->factory(Activity::class)->create(['id' => 12, 'user_id' => 2]);

        $this->when(function () {

            auth()->setUser(User::find(2));

            request()->offsetSet('id', 11);

            $this->assertError('authorized user who is related user of activity for [id] is required.');
        });

        $this->when(function () {

            auth()->setUser(User::find(1));

            request()->offsetSet('id', 12);

            $this->assertError('authorized user who is related user of activity for [id] is required.');
        });
    }

}
