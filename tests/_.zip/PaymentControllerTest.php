<?php

namespace Tests\Unit\App\Http\Controllers\Api;

use App\Database\Models\Payment;
use App\Database\Models\User;

class PaymentControllerTest extends _TestCase {

    public function testIndex()
    {
        $this->factory(User::class)->create(['id' => 1]);
        $this->factory(User::class)->create(['id' => 2]);
        $this->factory(Payment::class)->create(['id' => 11, 'user_id' => 1]);
        $this->factory(Payment::class)->create(['id' => 12, 'user_id' => 2]);
        $this->factory(Payment::class)->create(['id' => 13, 'user_id' => 2]);
        $this->factory(Payment::class)->create(['id' => 14, 'user_id' => 1]);

        $this->when(function () {

            auth()->setUser(User::find(1));

            $this->assertResultWithListing([11, 14]);
        });

        $this->when(function () {

            auth()->setUser(User::find(2));

            $this->assertResultWithListing([12, 13]);
        });
    }

    public function testIndexErrorRequiredRuleAuthUser()
    {
        $this->when(function () {

            $this->assertError('authorized user is required.');
        });
    }

    public function testShow()
    {
        $this->factory(User::class)->create(['id' => 1]);
        $this->factory(User::class)->create(['id' => 2]);
        $this->factory(Payment::class)->create(['id' => 11, 'user_id' => 1]);
        $this->factory(Payment::class)->create(['id' => 12, 'user_id' => 2]);

        $this->when(function () {

            auth()->setUser(User::find(1));
            request()->offsetSet('id', 11);

            $this->assertResultWithFinding(11);
        });

        $this->when(function () {

            auth()->setUser(User::find(2));
            request()->offsetSet('id', 12);

            $this->assertResultWithFinding(12);
        });
    }

    public function testShowErrorIntegerRuleId()
    {
        $this->when(function () {

            request()->offsetSet('id', [11]);

            $this->assertError('[id] must be an integer.');
        });

        $this->when(function () {

            request()->offsetSet('id', 'abcd');

            $this->assertError('[id] must be an integer.');
        });
    }

    public function testShowErrorNotNullRuleModel()
    {
        $this->when(function () {

            $this->factory(Payment::class)->create(['id' => 11]);
            $this->factory(Payment::class)->create(['id' => 12]);

            request()->offsetSet('id', 13);

            $this->assertError('payment for [id] must exist.');
        });
    }

    public function testShowErrorRequiredRuleAuthUser()
    {
        $this->when(function () {

            $this->assertError('authorized user is required.');
        });
    }

    public function testShowErrorRequiredRuleId()
    {
        $this->when(function () {

            $this->assertError('[id] is required.');
        });
    }

    public function testShowRequiredRulePermittedUser()
    {
        $this->when(function () {

            $this->factory(User::class)->create(['id' => 1]);
            $this->factory(Payment::class)->create(['id' => 11, 'user_id' => 2]);

            auth()->setUser(User::find(1));
            request()->offsetSet('id', 11);

            $this->assertError('authorized user who is related user of payment for [id] is required.');
        });
    }

}
