<?php

namespace Tests\Unit\App\Http\Controllers\Api;

use App\Database\Models\Role;
use App\Database\Models\User;

class AuthSignUpControllerTest extends _TestCase {

    public function testStore()
    {
        $this->when(function () {

            $gender   = User::GENDER_MAN;
            $password = 'some password';
            $email    = 'abcd@gmail.com';
            $name     = 'john smith';

            request()->offsetSet('gender', $gender);
            request()->offsetSet('password', $password);
            request()->offsetSet('email', $email);
            request()->offsetSet('name', $name);

            $this->assertResultWithPersisting(new User([
                User::GENDER
                    => User::GENDER_MAN,
                User::PASSWORD
                    => $password,
                User::NAME
                    => $name,
                User::EMAIL
                    => $email
            ]));
        });
    }

    public function testStoreErrorEmailRuleEmail()
    {
        $this->when(function () {

            request()->offsetSet('email', 'abcd');

            $this->assertError('[email] must be a valid email address.');
        });
    }

    public function testStoreErrorInRuleGender()
    {
        $this->when(function () {

            request()->offsetSet('gender', 'abcd');

            $this->assertError('[gender] is invalid.');
        });
    }

    public function testStoreErrorMinRulePassword()
    {
        $this->when(function () {

            request()->offsetSet('password', 'abcd');

            $this->assertError('[password] must be at least 6 characters.');
        });
    }

    public function testStoreErrorNotNullRuleSameEmailUser()
    {
        $this->when(function () {

            $this->factory(User::class)->create([
                User::EMAIL
                    => 'abcd@gmail.com'
            ]);

            $gender   = User::GENDER_MAN;
            $password = 'some password';
            $email    = 'abcd@gmail.com';
            $name     = 'john smith';

            request()->offsetSet('gender', $gender);
            request()->offsetSet('password', $password);
            request()->offsetSet('email', $email);
            request()->offsetSet('name', $name);

            $this->assertError('same email user for [email] must not exist.');
        });
    }

    public function testStoreErrorRequiredRuleEmail()
    {
        $this->when(function () {

            $this->assertError('[email] is required.');
        });
    }

    public function testStoreErrorRequiredRuleGender()
    {
        $this->when(function () {

            $this->assertError('[gender] is required.');
        });
    }

    public function testStoreErrorRequiredRuleName()
    {
        $this->when(function () {

            $this->assertError('[name] is required.');
        });
    }

    public function testStoreErrorRequiredRulePassword()
    {
        $this->when(function () {

            $this->assertError('[password] is required.');
        });
    }

    public function testStoreErrorStringRuleEmail()
    {
        $this->when(function () {

            request()->offsetSet('email', ['abcd']);

            $this->assertError('[email] must be a string.');
        });
    }

    public function testStoreErrorStringRuleGender()
    {
        $this->when(function () {

            request()->offsetSet('gender', ['abcd']);

            $this->assertError('[gender] must be a string.');
        });
    }

    public function testStoreErrorStringRuleName()
    {
        $this->when(function () {

            request()->offsetSet('name', ['abcd']);

            $this->assertError('[name] must be a string.');
        });
    }

    public function testStoreErrorStringRulePassword()
    {
        $this->when(function () {

            request()->offsetSet('password', ['abcd']);

            $this->assertError('[password] must be a string.');
        });
    }

}
