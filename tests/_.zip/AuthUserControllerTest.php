<?php

namespace Tests\Unit\App\Http\Controllers\Api;

use App\Database\Models\User;
use Tests\Unit\App\Http\Controllers\Api\_TestCase;

class AuthUserControllerTest extends _TestCase {

    public function testIndex()
    {
        $this->factory(User::class)->create(['id' => 1]);
        $this->factory(User::class)->create(['id' => 2]);

        $this->when(function () {

            auth()->setUser(User::find(1));

            $this->assertResultWithReturning(User::find(1));
        });

        $this->when(function () {

            auth()->setUser(User::find(2));

            $this->assertResultWithReturning(User::find(2));
        });

        $this->when(function () {

            auth()->logout();
            $this->assertResultWithReturning(null);
        });
    }

}
