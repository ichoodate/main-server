<?php

namespace Tests\Unit\App\Http\Controllers\Api\Keyword;

use App\Database\Models\Keyword\Country;
use App\Database\Models\Keyword\ResidenceCountry;
use Tests\Unit\App\Http\Controllers\Api\_TestCase;

class CountryResidenceCountryControllerTest extends _TestCase {

    public function testIndex()
    {
        $this->factory(Country::class)->create(['id' => 11]);
        $this->factory(Country::class)->create(['id' => 12]);
        $this->factory(ResidenceCountry::class)->create(['id' => 101, 'country_id' => 11]);
        $this->factory(ResidenceCountry::class)->create(['id' => 102, 'country_id' => 11]);
        $this->factory(ResidenceCountry::class)->create(['id' => 103, 'country_id' => 12]);

        $this->when(function () {

            request()->offsetSet('country_id', 11);

            $this->assertResultWithListing([101, 102]);
        });

        $this->when(function () {

            request()->offsetSet('country_id', 12);

            $this->assertResultWithListing([103]);
        });
    }

    public function testIndexErrorNotNullRuleCountryModel()
    {
        $this->when(function () {

            request()->offsetSet('country_id', 11);

            $this->assertError('country keyword for [country_id] must exist.');
        });
    }

    public function testIndexErrorIntegerRuleCountryId()
    {
        $this->when(function () {

            request()->offsetSet('country_id', [11]);

            $this->assertError('[country_id] must be an integer.');
        });

        $this->when(function () {

            request()->offsetSet('country_id', 'abcd');

            $this->assertError('[country_id] must be an integer.');
        });
    }

    public function testIndexErrorRequiredRuleCountryId()
    {
        $this->when(function () {

            $this->assertError('[country_id] is required.');
        });
    }

}
