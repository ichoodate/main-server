<?php

namespace Tests\Unit\App\Http\Controllers\Api\Keyword;

use App\Database\Models\Keyword\Drink;
use Tests\Unit\App\Http\Controllers\Api\_TestCase;

class DrinkControllerTest extends _TestCase {

    public function testIndex()
    {
        $this->when(function () {

            $this->factory(Drink::class)->create(['id' => 11]);
            $this->factory(Drink::class)->create(['id' => 12]);

            $this->assertResultWithListing([11, 12]);
        });

        $this->when(function () {

            $this->factory(Drink::class)->create(['id' => 12]);
            $this->factory(Drink::class)->create(['id' => 13]);

            $this->assertResultWithListing([12, 13]);
        });
    }

    public function testShow()
    {
        $this->factory(Drink::class)->create(['id' => 11]);
        $this->factory(Drink::class)->create(['id' => 12]);

        $this->when(function () {

            request()->offsetSet('id', 11);

            $this->assertResultWithFinding(11);
        });

        $this->when(function () {

            request()->offsetSet('id', 12);

            $this->assertResultWithFinding(12);
        });
    }

    public function testShowErrorIntegerRuleId()
    {
        $this->when(function () {

            request()->offsetSet('id', [11]);

            $this->assertError('[id] must be an integer.');
        });

        $this->when(function () {

            request()->offsetSet('id', 'abcd');

            $this->assertError('[id] must be an integer.');
        });
    }

    public function testShowErrorRequiredRuleId()
    {
        $this->when(function () {

            $this->assertError('[id] is required.');
        });
    }

}
