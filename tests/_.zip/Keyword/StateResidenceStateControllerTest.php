<?php

namespace Tests\Unit\App\Http\Controllers\Api\Keyword;

use App\Database\Models\Keyword\State;
use App\Database\Models\Keyword\ResidenceState;
use Tests\Unit\App\Http\Controllers\Api\_TestCase;

class StateResidenceStateControllerTest extends _TestCase {

    public function testIndex()
    {
        $this->factory(State::class)->create(['id' => 11]);
        $this->factory(State::class)->create(['id' => 12]);
        $this->factory(ResidenceState::class)->create(['id' => 101, 'state_id' => 11]);
        $this->factory(ResidenceState::class)->create(['id' => 102, 'state_id' => 11]);
        $this->factory(ResidenceState::class)->create(['id' => 103, 'state_id' => 12]);

        $this->when(function () {

            request()->offsetSet('state_id', 11);

            $this->assertResultWithListing([101, 102]);
        });

        $this->when(function () {

            request()->offsetSet('state_id', 12);

            $this->assertResultWithListing([103]);
        });
    }

    public function testIndexErrorNotNullRuleStateModel()
    {
        $this->when(function () {

            request()->offsetSet('state_id', 11);

            $this->assertError('state keyword for [state_id] must exist.');
        });
    }

    public function testIndexErrorIntegerRuleStateId()
    {
        $this->when(function () {

            request()->offsetSet('state_id', [11]);

            $this->assertError('[state_id] must be an integer.');
        });

        $this->when(function () {

            request()->offsetSet('state_id', 'abcd');

            $this->assertError('[state_id] must be an integer.');
        });
    }

    public function testIndexErrorRequiredRuleStateId()
    {
        $this->when(function () {

            $this->assertError('[state_id] is required.');
        });
    }

}
