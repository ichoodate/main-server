<?php

namespace Tests\Unit\App\Http\Controllers\Api;

use Closure;
use Tests\Unit\_TestCase as TestCase;
use App\Database\Model;

class _TestCase extends TestCase {

    public function assertPersistence($model, $existCount = 1)
    {
        $attrs = $model->getAttributes();
        $query = inst(get_class($model))->query();

        foreach ( $attrs as $attr => $value )
        {
            $query->where($attr, $value);
        }

        $this->assertEquals($existCount, $query->count());
    }

    public function assertDeletion($model)
    {
        $this->assertPersistence($model, 0);
    }

    public function assertError($msg)
    {
        $serv  = $this->executedService();
        $errors = $serv->totalErrors()->all();

        $this->assertContains($msg, $errors, implode(',', $errors));
    }

    public function assertResult($expect)
    {
        $serv   = $this->executedService();
        $result = $serv->data()->get('result');

        $this->assertEquals($result, $expect);
    }

    public function assertResultWithPersisting($expects)
    {
        $serv   = $this->executedService();
        $result = $serv->data()->get('result');
        $errors = $serv->totalErrors()->all();

        if ( $expects instanceof Model )
        {
            $this->assertInstanceOf(Model::class, $result);

            $expects = collect([$expects]);
            $result  = collect([$result]);
        }

        $this->assertEquals([], $errors, implode(',', $errors));
        $this->assertEquals(get_class($expects), get_class($result));

        foreach ( $result as $i => $model )
        {
            $expect = $expects[$i];

            $this->assertInstanceOf(Model::class, $model);
            $this->assertEquals(get_class($expect), get_class($model));
            $this->assertEquals([], array_diff($expect->toArray(), $model->toArray()));
        }
    }

    public function assertResultWithFinding($expectId)
    {
        $serv   = $this->executedService();
        $result = $serv->data()->get('result');
        $errors = $serv->totalErrors()->all();

        $this->assertEquals([], $errors, implode(',', $errors));
        $this->assertInstanceOf(Model::class, $result);
        $this->assertEquals($result->getKey(), $expectId);
    }

    public function assertResultWithListing($expectIds)
    {
        $serv   = $this->executedService();
        $result = $serv->data()->get('result');
        $errors = $serv->totalErrors()->all();

        $this->assertEquals([], $errors, implode(',', $errors));

        foreach ( $expectIds as $expectId )
        {
            $this->assertContains($expectId, $result->modelKeys());
        }
    }

    public function assertResultWithPaging($expectIds)
    {
        $serv   = $this->executedService();
        $result = $serv->data()->get('result');
        $errors = $serv->totalErrors()->all();

        $builder = $serv->data()->get('query');
        $addSlashes = str_replace('?', "'?'", $builder->toSql());
        $q = vsprintf(str_replace('?', '%s', $addSlashes), $builder->getBindings());

        $this->assertEquals([], $errors, implode(',', $errors));
        $this->assertEquals($result->modelKeys(), $expectIds);
    }

    public function assertResultWithReturning($expect)
    {
        $serv   = $this->executedService();
        $result = $serv->data()->get('result');
        $errors = $serv->totalErrors()->all();

        $this->assertEquals([], $errors, implode(',', $errors));
        $this->assertEquals($expect, $result);
    }

    public function getTestName()
    {
        $traces = debug_backtrace();

        foreach ( $traces as $trace )
        {
            if ( array_key_exists('class', $trace) && is_a($trace['class'], static::class, true) && starts_with($trace['function'], 'test') )
            {
                return $trace['function'];
            }
        }

        throw new \Exception('test function not exists.');
    }

    public function getAction($testFuncName)
    {
        if ( starts_with($testFuncName, 'testDestroy') )
        {
            $action = 'delete';
        }
        else if ( starts_with($testFuncName, 'testIndex') )
        {
            $action = 'index';
        }
        else if ( starts_with($testFuncName, 'testStore') )
        {
            $action = 'store';
        }
        else if ( starts_with($testFuncName, 'testUpdate') )
        {
            $action = 'update';
        }
        else if ( starts_with($testFuncName, 'testShow') )
        {
            $action = 'show';
        }
        else
        {
            throw new \Exception;
        }

        return $action;
    }

    public function executedService()
    {
        $class   = static::class();
        $func    = $this->getTestName();
        $action  = $this->getAction($func);
        $arr     = $class::$action();
        $service = $class::servicify($arr);

        $service->run();

        $this->result = $service->data()->get('result');

        return $service;
    }

    public function setInput($key, $value)
    {
        request()->offsetSet($key, $value);
    }

    public function setInputDefault()
    {
        $func   = $this->getTestName();
        $action = $this->getAction($func);
        $inputs = $this->{'defaultFor' . ucfirst($action)}();

        foreach ( $inputs as $key => $value )
        {
            if ( ! in_array($key, request()->keys()) )
            {
                request()->offsetSet($key, $value);
            }
        }
    }

    public function when()
    {
        $args = func_get_args();

        app('db')->beginTransaction();

        call_user_func($args[0]);

        app('db')->rollback();
    }

    public function testTestMethodImplement()
    {
        $class   = $this->class();
        $parent  = get_parent_class($class);
        $methods = array_diff(get_class_methods($class), get_class_methods($parent));

        foreach ( $methods as $method )
        {
            $this->assertContains('test' . ucfirst($method), get_class_methods(static::class));
        }
    }

}
