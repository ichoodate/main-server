<?php

namespace Tests\Unit\App\Http\Controllers\Api;

use App\Database\Models\User;
use Tests\Unit\App\Http\Controllers\Api\_TestCase;

class AuthSignInControllerTest extends _TestCase {

    public function testStore()
    {
        $user = $this->factory(User::class)->create([
            'id' => 1,
            'email' => 'abc123@example.com',
            'password' => bcrypt('abcdef')
        ]);

        $this->when(function () {

            request()->offsetSet('email', 'abc123@example.com');
            request()->offsetSet('password', 'abcdef');

            $this->assertResult(true);
            $this->assertEquals(auth()->user(), User::find(1));
        });
    }

    public function testStoreErrorEmailRuleEmail()
    {
        $this->when(function () {

            request()->offsetSet('email', 'affsefs@fefs');

            $this->assertError('[email] must be a valid email address.');
        });
    }

    public function testStoreErrorRequiredRuleEmail()
    {
        $this->when(function () {

            $this->assertError('[email] is required.');
        });
    }

    public function testStoreErrorRequiredRulePassword()
    {
        $this->when(function () {

            $this->assertError('[password] is required.');
        });
    }

}
