<?php

namespace Tests\Unit\App\Http\Controllers\Api;

use App\Database\Models\ChattingContent;
use App\Database\Models\Match;
use App\Database\Models\User;
use Tests\Unit\App\Http\Controllers\Api\_TestCase;

class MatchChattingContentControllerTest extends _TestCase {

    public function testIndex()
    {
        $this->factory(User::class)->create(['id' => 1]);
        $this->factory(User::class)->create(['id' => 2]);
        $this->factory(User::class)->create(['id' => 3]);
        $this->factory(User::class)->create(['id' => 4]);
        $this->factory(Match::class)->create(['id' => 11, 'man_id' => 1, 'woman_id' => 2]);
        $this->factory(Match::class)->create(['id' => 12, 'man_id' => 3, 'woman_id' => 4]);
        $this->factory(ChattingContent::class)->create(['id' => 101, 'writer_id' => 1, 'match_id' => 11]);
        $this->factory(ChattingContent::class)->create(['id' => 102, 'writer_id' => 2, 'match_id' => 11]);
        $this->factory(ChattingContent::class)->create(['id' => 103, 'writer_id' => 3, 'match_id' => 12]);

        $this->when(function () {

            auth()->setUser(User::find(1));
            request()->offsetSet('match_id', 11);

            $this->assertResultWithListing([101, 102]);
        });

        $this->when(function () {

            auth()->setUser(User::find(2));
            request()->offsetSet('match_id', 11);

            $this->assertResultWithListing([101, 102]);
        });

        $this->when(function () {

            auth()->setUser(User::find(4));
            request()->offsetSet('match_id', 12);

            $this->assertResultWithListing([103]);
        });
    }

    public function testIndexIntegerRuleMatchId()
    {
        $this->when(function () {

            request()->offsetSet('match_id', [11]);

            $this->assertError('[match_id] must be an integer.');
        });
    }

    public function testIndexNotNullRuleMatchModel()
    {
        $this->when(function () {

            $this->factory(User::class)->create(['id' => 1]);

            auth()->setUser(User::find(1));
            request()->offsetSet('match_id', 1234);

            $this->assertError('match for [match_id] must exist.');
        });
    }

    public function testIndexRequiredRuleAuthUser()
    {
        $this->when(function () {

            $this->assertError('authorized user is required.');
        });
    }

    public function testIndexRequiredRuleMatchId()
    {
        $this->when(function () {

            $this->assertError('[match_id] is required.');
        });
    }

    public function testIndexRequiredRulePermittedUser()
    {
        $this->when(function () {

            $this->factory(User::class)->create(['id' => 3]);
            $this->factory(Match::class)->create(['id' => 11, 'man_id' => 1, 'woman_id' => 2]);

            auth()->setUser(User::find(3));
            request()->offsetSet('match_id', 11);

            $this->assertError('authorized user who is related user of match for [match_id] is required.');
        });
    }

}
