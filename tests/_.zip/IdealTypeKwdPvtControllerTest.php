<?php

namespace Tests\Unit\App\Http\Controllers\Api;

use App\Database\Models\Keyword\Body;
use App\Database\Models\Keyword\Blood;
use App\Database\Models\Obj;
use App\Database\Models\UserIdealTypeKwdPvt;
use App\Database\Models\User;
use Tests\Unit\App\Http\Controllers\Api\_TestCase;

class IdealTypeKwdPvtControllerTest extends _TestCase {

    public function testIndex()
    {
        $this->factory(User::class)->create(['id' => 1]);
        $this->factory(User::class)->create(['id' => 2]);
        $this->factory(UserIdealTypeKwdPvt::class)->create(['id' => 11, 'user_id' => 1]);
        $this->factory(UserIdealTypeKwdPvt::class)->create(['id' => 12, 'user_id' => 2]);
        $this->factory(UserIdealTypeKwdPvt::class)->create(['id' => 13, 'user_id' => 2]);
        $this->factory(UserIdealTypeKwdPvt::class)->create(['id' => 14, 'user_id' => 1]);

        $this->when(function () {

            auth()->setUser(User::find(1));

            $this->assertResultWithListing([11, 14]);
        });

        $this->when(function () {

            auth()->setUser(User::find(2));

            $this->assertResultWithListing([12, 13]);
        });
    }

    public function testIndexErrorRequiredRuleAuthUser()
    {
        $this->when(function () {

            $this->assertError('authorized user is required.');
        });
    }

    public function testStore()
    {
        $this->when(function () {

            $this->factory(User::class)->create(['id' => 1]);
            $this->factory(Body::class)->create(['id' => 11]);
            $this->factory(Blood::class)->create(['id' => 12]);

            auth()->setUser(User::find(1));
            request()->offsetSet('keyword_ids', 11 . ','. 12);

            $this->assertResultWithPersisting((new UserIdealTypeKwdPvt)->newCollection([new UserIdealTypeKwdPvt([
                'user_id' => 1,
                'keyword_id' => 11
            ]), new UserIdealTypeKwdPvt([
                'user_id' => 1,
                'keyword_id' => 12
            ])]));
        });
    }

    public function testStoreErrorIntegersRuleKeywordIds()
    {
        $this->when(function () {

            request()->offsetSet('keyword_ids', '1234,abcd');

            $this->assertError('[keyword_ids] must be integers separated by commas.');
        });

        $this->when(function () {

            request()->offsetSet('keyword_ids', [1234]);

            $this->assertError('[keyword_ids] must be integers separated by commas.');
        });
    }

    public function testStoreErrorRequiredRuleAuthUser()
    {
        $this->when(function () {

            $this->assertError('authorized user is required.');
        });
    }

    public function testStoreErrorRequiredRuleKeywordIds()
    {
        $this->when(function () {

            $this->assertError('[keyword_ids] is required.');
        });
    }

    public function testShow()
    {
        $this->factory(User::class)->create(['id' => 1]);
        $this->factory(User::class)->create(['id' => 2]);
        $this->factory(UserIdealTypeKwdPvt::class)->create(['id' => 11, 'user_id' => 1]);
        $this->factory(UserIdealTypeKwdPvt::class)->create(['id' => 12, 'user_id' => 2]);

        $this->when(function () {

            auth()->setUser(User::find(1));
            request()->offsetSet('id', 11);

            $this->assertResultWithFinding(11);
        });

        $this->when(function () {

            auth()->setUser(User::find(2));
            request()->offsetSet('id', 12);

            $this->assertResultWithFinding(12);
        });
    }

    public function testShowErrorIntegerRuleId()
    {
        $this->when(function () {

            request()->offsetSet('id', [11]);

            $this->assertError('[id] must be an integer.');
        });

        $this->when(function () {

            request()->offsetSet('id', 'abcd');

            $this->assertError('[id] must be an integer.');
        });
    }

    public function testShowErrorNotNullRuleModel()
    {
        $this->when(function () {

            $this->factory(UserIdealTypeKwdPvt::class)->create(['id' => 11]);
            $this->factory(UserIdealTypeKwdPvt::class)->create(['id' => 12]);

            request()->offsetSet('id', 13);

            $this->assertError('user_ideal_type_kwd_pvt for [id] must exist.');
        });
    }

    public function testShowErrorRequiredRuleAuthUser()
    {
        $this->when(function () {

            $this->assertError('authorized user is required.');
        });
    }

    public function testShowErrorRequiredRuleId()
    {
        $this->when(function () {

            $this->assertError('[id] is required.');
        });
    }

    public function testShowRequiredRulePermittedUser()
    {
        $this->when(function () {

            $this->factory(User::class)->create(['id' => 1]);
            $this->factory(UserIdealTypeKwdPvt::class)->create(['id' => 11, 'user_id' => 2]);

            auth()->setUser(User::find(1));
            request()->offsetSet('id', 11);

            $this->assertError('authorized user who is related user of ideal_type_kwd_pvt for [id] is required.');
        });
    }

}
