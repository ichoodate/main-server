<?php

namespace Tests\Unit\App\Http\Controllers\Api;

use App\Database\Models\PwdReset;
use App\Database\Models\User;
use Illuminate\Support\Facades\Hash;

class PwdResetControllerTest extends _TestCase {

    public function testStore()
    {
        $this->factory(User::class)->create([
            User::ID => 1,
            User::EMAIL => 'abcd@gmail.com'
        ]);

        $this->when(function () {

            request()->offsetSet('email', 'abcd@gmail.com');

            $this->assertResultWithPersisting(new PwdReset([
                PwdReset::EMAIL => 'abcd@gmail.com',
                PwdReset::COMPLETE => false
            ]));
        });
    }

    public function testStoreErrorEmailRuleEmail()
    {
        $this->when(function () {

            request()->offsetSet('email', 'abcd');

            $this->assertError('[email] must be a valid email address.');
        });
    }

    public function testStoreErrorRequiredRuleEmail()
    {
        $this->when(function () {

            $this->assertError('[email] is required.');
        });
    }

    public function testPut()
    {
        $this->factory(User::class)->create([
            User::ID => 1,
            User::EMAIL => 'abcd@gmail.com'
        ]);

        $this->factory(PwdReset::class)->create([
            PwdReset::ID    => 'de99a620c50f2990e87144735cd357e7',
            PwdReset::EMAIL => 'abcd@gmail.com'
        ]);

        $this->when(function () {

            request()->offsetSet('id', 'de99a620c50f2990e87144735cd357e7');
            request()->offsetSet('new_password', 'abcdef');

            $this->assertResultWithPersisting(new PwdReset([
                PwdReset::ID => 'de99a620c50f2990e87144735cd357e7',
                PwdReset::EMAIL => 'abcd@gmail.com',
                PwdReset::COMPLETE => true
            ]));

            $this->assertTrue(Hash::check('abcdef', User::find(1)->password));
            $this->assertTrue(auth()->attempt([
                User::EMAIL => 'abcd@gmail.com',
                User::PASSWORD => 'abcdef'
            ]));
        });
    }

    public function testPutErrorRequiredRuleId()
    {
        $this->when(function () {

            $this->assertError('[id] is required.');
        });
    }

    public function testPutErrorRequiredRuleNewPassword()
    {
        $this->when(function () {

            $this->assertError('[new_password] is required.');
        });
    }

    public function testPutErrorStringRuleId()
    {
        $this->when(function () {

            request()->offsetSet('id', ['abcd']);

            $this->assertError('[id] must be a string.');
        });
    }

    public function testPutErrorStringRuleNewPassword()
    {
        $this->when(function () {

            request()->offsetSet('new_password', ['abcd']);

            $this->assertError('[new_password] must be a string.');
        });
    }

    public function testShow()
    {
        $this->factory(PwdReset::class)->create([
            PwdReset::ID => 'de99a620c50f2990e87144735cd357e7'
        ]);
        $this->factory(PwdReset::class)->create([
            PwdReset::ID => '582245b119d43c6b3d479ca7ce4e0e21'
        ]);

        $this->when(function () {

            request()->offsetSet('id', 'de99a620c50f2990e87144735cd357e7');

            $this->assertResultWithFinding('de99a620c50f2990e87144735cd357e7');
        });
    }

    public function testShowErrorRequiredRuleId()
    {
        $this->when(function () {

            $this->assertError('[id] is required.');
        });
    }

}
